
package controlador;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Ctrl_BD {
    public static Connection conexion;
    public static ResultSet rs;
    public static DatabaseMetaData md ;
    public static ResultSetMetaData rsmd;
    public Statement st;
    private String xusuario;
    private ArrayList<String> listaTablas;
    private ArrayList<String> listaColumnas ;
    
    
    //Método de conexion a la base de datos
    public static int conectarOracle(String localhost,String puerto,String user,String password){
        int res = 0;
        try{
            conexion = DriverManager.getConnection("jdbc:oracle:thin:@"+localhost+":"+puerto+":xe",user,password);
        }catch(SQLException ex){ res = -1;}
        
        return res;
    }
   
    //Método que devuelve la lista de tablas de nuestra base de datos
    public ArrayList<String> obtenerTablas(String usuario) {
        listaTablas = new ArrayList<>();
        xusuario = usuario;
        
        try {
            md = conexion.getMetaData();
            ResultSet rs = md.getTables(null, xusuario, "%", null);
            while (rs.next()) {
                listaTablas.add(rs.getString(3));
            }

        } catch (SQLException ex) {
        }
        return listaTablas;
    }
    
    //Método que devuelve la lista de columnas de la tabla seleccionada
    public  ArrayList<String> obtenerColumnas(String tabla) {
        listaColumnas = new ArrayList<>();

        try {
            rs = md.getColumns(null,xusuario,tabla,null); 
            while (rs.next()) {
                listaColumnas.add(rs.getString(4));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return listaColumnas;
    }   
    
    //Método que devuelve el tipo de dato de la columna en la que estamos
    public String obtenerComparadores(String tabla,String columna){
        String tipo="";
        
        try{
            rs = md.getColumns(null, xusuario,tabla, columna);
            
            while(rs.next()){
                tipo = rs.getString(6);
            }
       
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        return tipo;
    }
    
    //Método para obtener los datos de la consulta
    public ResultSet obtenerDatos(String consulta){
         
        try{
            st = conexion.createStatement();
            rs = null;
            rs = st.executeQuery(consulta);
                    
        }catch(SQLException ex){
        }catch(NullPointerException ex){}
        
     return rs;
    }
    
    public DatabaseMetaData getMD(){
        return md;
    }
}
