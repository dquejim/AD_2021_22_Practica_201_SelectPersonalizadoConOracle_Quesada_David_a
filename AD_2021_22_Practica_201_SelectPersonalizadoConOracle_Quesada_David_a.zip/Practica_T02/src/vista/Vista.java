package vista;

import controlador.Ctrl_BD;
import java.awt.event.ItemEvent;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Vista extends javax.swing.JFrame {

    private Ctrl_BD ctrl = new Ctrl_BD();
    private ArrayList<String> listaTablas;
    private ArrayList<String> listaColumnas;
    private ArrayList<Object> listaDatos;
    private int comparador;
    DefaultTableModel modelo;

    public Vista() {
        initComponents();
        jParametros.setVisible(true);
        jParametros.setLocationRelativeTo(this);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jParametros = new javax.swing.JDialog();
        jTextPuerto = new javax.swing.JTextField();
        jTextUsuario = new javax.swing.JTextField();
        jTextPassword = new javax.swing.JTextField();
        jBAceptar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jBCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextServidor = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jCombColumnas = new javax.swing.JComboBox<>();
        jCombTablas = new javax.swing.JComboBox<>();
        jCombOperador = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextSelect = new javax.swing.JTextField();
        jBEjecutar = new javax.swing.JButton();
        jTextValor = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jBRefresh = new javax.swing.JButton();

        jParametros.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jParametros.setTitle("Conexión a la Base de Datos");
        jParametros.setLocation(new java.awt.Point(0, 0));
        jParametros.setLocationByPlatform(true);
        jParametros.setMinimumSize(new java.awt.Dimension(661, 509));
        jParametros.setModal(true);
        jParametros.setResizable(false);
        jParametros.setSize(new java.awt.Dimension(661, 500));
        jParametros.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                jParametrosWindowClosing(evt);
            }
        });

        jTextPuerto.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        jTextUsuario.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        jTextPassword.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        jBAceptar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jBAceptar.setText("Aceptar");
        jBAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAceptarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setText("Servidor:");

        jBCancelar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jBCancelar.setText("Cancelar");
        jBCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCancelarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setText("Password:");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel3.setText("Puerto:");

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel4.setText("Usuario:");

        jTextServidor.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        javax.swing.GroupLayout jParametrosLayout = new javax.swing.GroupLayout(jParametros.getContentPane());
        jParametros.getContentPane().setLayout(jParametrosLayout);
        jParametrosLayout.setHorizontalGroup(
            jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jParametrosLayout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jParametrosLayout.createSequentialGroup()
                        .addComponent(jBAceptar)
                        .addGap(33, 33, 33)
                        .addComponent(jBCancelar)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jParametrosLayout.createSequentialGroup()
                        .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                        .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextServidor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextPuerto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextUsuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextPassword, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(58, 58, 58))
        );
        jParametrosLayout.setVerticalGroup(
            jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jParametrosLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextServidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextPuerto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jTextUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jParametrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBAceptar)
                    .addComponent(jBCancelar))
                .addContainerGap(69, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AD_TEMA_03_FACTURAS");

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel5.setText("Tablas:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 49, -1, -1));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel6.setText("Operador:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 218, -1, -1));

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel7.setText("Columnas:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 134, -1, -1));

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel8.setText("Valor:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 309, -1, -1));

        jCombColumnas.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jCombColumnas.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCombColumnasItemStateChanged(evt);
            }
        });
        jPanel1.add(jCombColumnas, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 129, 349, -1));

        jCombTablas.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jCombTablas.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCombTablasItemStateChanged(evt);
            }
        });
        jPanel1.add(jCombTablas, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 44, 349, -1));

        jCombOperador.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jPanel1.add(jCombOperador, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 213, 349, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(697, 47, 750, 290));

        jTextSelect.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jPanel1.add(jTextSelect, new org.netbeans.lib.awtextra.AbsoluteConstraints(161, 402, 977, 40));

        jBEjecutar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jBEjecutar.setText("Ejecutar");
        jBEjecutar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEjecutarActionPerformed(evt);
            }
        });
        jPanel1.add(jBEjecutar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1319, 402, 139, -1));

        jTextValor.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jTextValor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextValorFocusLost(evt);
            }
        });
        jPanel1.add(jTextValor, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 305, 349, -1));
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 355, -1, -1));

        jBRefresh.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jBRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh.png"))); // NOI18N
        jBRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBRefreshActionPerformed(evt);
            }
        });
        jPanel1.add(jBRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 402, 49, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1524, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 539, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    //Accion al pulsar el boton aceptar del jDialog, que recoge los datos insertados e intenta la conexion a la base de datos
    private void jBAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAceptarActionPerformed
        String localhost, puerto, sid, user, password;
        localhost = jTextServidor.getText();
        puerto = jTextPuerto.getText();
        user = jTextUsuario.getText();
        password = jTextPassword.getText();
        int conectado = ctrl.conectarOracle(localhost, puerto, user, password);

        //Si la conexion falla
        if (conectado == -1) {
          JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos");
          //Si la conexion se realiza correctamente
        } else {
            jParametros.setVisible(false);
            listaTablas = ctrl.obtenerTablas(user);
            rellenoComboBox(jCombTablas, listaTablas);
        }
    }//GEN-LAST:event_jBAceptarActionPerformed
    
    //Método de relleno de los comboBox tablas y columnas
    private void rellenoComboBox(JComboBox box, ArrayList<String> lista) {

        for (String elemento : lista) {
            box.addItem(elemento);
        }

    }

    //Boton de cancelar y cerrar del jDialog Inicial
    private void jBCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCancelarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jBCancelarActionPerformed

    private void jParametrosWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_jParametrosWindowClosing
        System.exit(0);
    }//GEN-LAST:event_jParametrosWindowClosing

    //Accion del jComboBox al cambiar la seleccion de la tabla
    private void jCombTablasItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCombTablasItemStateChanged
        if (evt.getStateChange() == ItemEvent.SELECTED) {
            jCombColumnas.removeAllItems();
            String seleccion = (String) jCombTablas.getSelectedItem();
            listaColumnas = ctrl.obtenerColumnas(seleccion);
            rellenoComboBox(jCombColumnas, listaColumnas);
        }
    }//GEN-LAST:event_jCombTablasItemStateChanged

    //Accion del jComboBox de columnas cada vez que cambiamos la seleccion
    private void jCombColumnasItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCombColumnasItemStateChanged
        if (evt.getStateChange() == ItemEvent.SELECTED) {
            jCombOperador.removeAllItems();

            //Relleno del jComboBox dependiendo del tipo de dato seleccionado
            String tipoDato = ctrl.obtenerComparadores(jCombTablas.getSelectedItem().toString(), jCombColumnas.getSelectedItem().toString());
            switch (tipoDato) {
                case "NUMBER":
                    jCombOperador.addItem("<");
                    jCombOperador.addItem(">");
                    jCombOperador.addItem("=");
                    jCombOperador.addItem(">=");
                    jCombOperador.addItem("<=");
                    comparador = 1;
                    break;

                case "VARCHAR2":
                    jCombOperador.addItem("=");
                    jCombOperador.addItem("LIKE");
                    comparador = 2;
                    break;

                case "DATE":
                    jCombOperador.addItem("<");
                    jCombOperador.addItem(">");
                    jCombOperador.addItem("=");
                    jCombOperador.addItem(">=");
                    jCombOperador.addItem("<=");
                    comparador = 3;
                    break;

            }
        }
    }//GEN-LAST:event_jCombColumnasItemStateChanged
    //Accion al perder el foco en el campo de relleno del valor 
    private void jTextValorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextValorFocusLost
        rellenarConsulta();
    }//GEN-LAST:event_jTextValorFocusLost

    //Método para llenar el texto de la consulta dependiendo del tipo de dato y los requisitos de la misma
    private void rellenarConsulta(){
        String tabla = jCombTablas.getSelectedItem().toString();
        String columna = jCombColumnas.getSelectedItem().toString();
        String operador = jCombOperador.getSelectedItem().toString();
        String valor = jTextValor.getText();
        valor = valor.toUpperCase();

        //Comparadores
        jTextSelect.setText("");
        if (comparador == 1) {
            jTextSelect.setText("SELECT * FROM " + tabla + " WHERE " + columna + " " + operador + " " + valor);
        }
        
        if ((comparador == 2) && operador != "LIKE") {
            jTextSelect.setText("SELECT * FROM " + tabla + " WHERE " + columna + " " + operador + " " + "'" + valor + "'");
        }
        
        if(operador == "LIKE"){
            jTextSelect.setText("SELECT * FROM " + tabla + " WHERE " + columna + " " + operador + " " + "'%" + valor + "%'");
        }
        
        if(comparador == 3){
            jTextSelect.setText("SELECT * FROM " + tabla + " WHERE " + columna + " " + operador + " " + "TO_DATE('"+valor+"','DD-MM-YYYY')");
        }
        if(jTextValor.getText().isEmpty()){
            jTextSelect.setText("SELECT * FROM " + tabla);
        }
    }
    
    //Boton que ejecuta la consulta y nos la añade al jTable
    private void jBEjecutarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEjecutarActionPerformed
        
        //Relleno de la cabecera del jtable dependiendo de la tabla seleccionada
        modelo = new DefaultTableModel();
        
        ResultSet rs = ctrl.obtenerDatos(jTextSelect.getText());
        
        //Aquí añadimos los datos de los registros con sus columnas correspondientes
        try{
            ResultSetMetaData rsmd = rs.getMetaData();
    
            for(int i = 0;i<rsmd.getColumnCount();i++){
                modelo.addColumn(rsmd.getColumnName(i+1));
            }
                       
            while (rs.next()) {
                Object[] fila = new Object[rsmd.getColumnCount()]; 

                for (int i = 0; i < rsmd.getColumnCount(); i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                
                modelo.addRow(fila);
            }
                   
        }catch(SQLException ex){
        }catch(NullPointerException ex){
            JOptionPane.showMessageDialog(this, "Error al ejectuar la consulta");
        }
        
        jTable1.setModel(modelo); 
    }//GEN-LAST:event_jBEjecutarActionPerformed

    //Botón para refrescar la consulta en caso necesario
    private void jBRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBRefreshActionPerformed
        rellenarConsulta();
    }//GEN-LAST:event_jBRefreshActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAceptar;
    private javax.swing.JButton jBCancelar;
    private javax.swing.JButton jBEjecutar;
    private javax.swing.JButton jBRefresh;
    private javax.swing.JComboBox<String> jCombColumnas;
    private javax.swing.JComboBox<String> jCombOperador;
    private javax.swing.JComboBox<String> jCombTablas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JDialog jParametros;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextPassword;
    private javax.swing.JTextField jTextPuerto;
    private javax.swing.JTextField jTextSelect;
    private javax.swing.JTextField jTextServidor;
    private javax.swing.JTextField jTextUsuario;
    private javax.swing.JTextField jTextValor;
    // End of variables declaration//GEN-END:variables
}
